# We Will Add Relevant Info About App Here

## Getting Started

### Prerequisites

Ensure you have **Node.js** installed. You can download it from the [Node.js official website](https://nodejs.org/).

### Installation

Clone the repository:

bash
Copy code
git clone https://github.com/SaileshAcharyaCodeRepository/swe_632_project.git
Navigate into the project directory:

bash
Copy code
cd swe_632_project
Install dependencies (this will install react-router-dom and other required packages):

bash
Copy code
npm install
Running the App
Once dependencies are installed, you can start the development server:

bash
Copy code
npm start
Data
The JSON file that contains product and price data is located in the public directory of the project folder.
